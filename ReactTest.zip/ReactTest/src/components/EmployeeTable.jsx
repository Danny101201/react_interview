import React, { useState, useMemo } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import TablePagination from '@mui/material/TablePagination';

import EnhanceTableHead from './EnhanceTableHead';
import {
  getComparator,
  stableSort
} from '../utils/table';
const headCells = [
  {
    id: 'Name',
    disablePadding: false,
    label: 'Name',
  },
  {
    id: 'Work_Type',
    disablePadding: false,
    label: 'Work Type',
  },
  {
    id: 'Start_Time',
    disablePadding: false,
    label: 'Start time',
  },
  {
    id: 'End_Time',
    disablePadding: false,
    label: 'End Time',
  },
];
const employeeType = [
  { id: 1, name: 'FullTime', work_begin: '09:00:00', work_end: '17:00:00' },
  { id: 2, name: 'MidTime', work_begin: '12:00:00', work_end: '21:00:00' },
  { id: 3, name: 'HalfTime', work_begin: '20:00:00', work_end: '00:00:00' },
]
const employees = [
  { id: 1, name: 'Alice', type: 2 },
  { id: 2, name: 'Bob', type: 3 },
  { id: 3, name: 'John', type: 2 },
  { id: 4, name: 'Karen', type: 1 },
  { id: 5, name: 'Miles', type: 3 },
  { id: 6, name: 'Henry', type: 1 },
]

function EmployeeTable({ selectData, setSelectData }) {
  const [rowsPerPage, setRowsPerPage] = useState(5)
  const [page, setPage] = useState(0)
  const [order, setOrder] = React.useState('asc');
  const [orderBy, setOrderBy] = React.useState('Name');

  const EmployeeWorkList = useMemo(() =>
    employees.reduce((acc, item) => {
      let transFormItem = {
        Name: item.name,
        Work_Type: employeeType.find(e => e.id === item.type).name,
        Start_Time: employeeType.find(e => e.id === item.type).work_begin,
        End_Time: employeeType.find(e => e.id === item.type).work_end,
      }
      acc.push(transFormItem)
      return acc
    }, [])
    , [])

  const handleRequestSort = (property) => {
    const isAsc = order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  return (
    <TableContainer component={Paper} className="rounded-md">
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <EnhanceTableHead
              orderBy={orderBy}
              order={order}
              headCells={headCells}
              handleRequestSort={handleRequestSort}
            />
          </TableRow>
        </TableHead>
        <TableBody >
          {
            stableSort(EmployeeWorkList, getComparator(order, orderBy))
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row, index) => (
                <TableRow
                  key={row.name}
                  onClick={() => setSelectData(row)}
                  style={{ backgroundColor: selectData && selectData['Name'] === row['Name'] ? '#EFF5FF' : '' }}
                  className={`${index % 2 === 0 ? 'bg-[#FAFAFA]' : ''} hover:bg-[#EEEEEE]`}
                  sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                >

                  <TableCell component="th" scope="row">
                    {row['Name']}
                  </TableCell>

                  <TableCell align="left">{row['Work_Type']}</TableCell>
                  <TableCell align="left">{row['Start_Time']}</TableCell>
                  <TableCell align="left">{row['End_Time']}</TableCell>
                </TableRow>
              ))}
        </TableBody>
      </Table>
      <TablePagination
        rowsPerPageOptions={[5, 10, 25]}
        component="div"
        count={EmployeeWorkList.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </TableContainer>
  )
}

export default EmployeeTable

