import React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

import EnhanceTableHead from './EnhanceTableHead';

import {
  getComparator,
  stableSort
} from '../utils/table';

const headCells = [
  {
    id: 'Title',
    disablePadding: false,
    label: 'Title',
  },
  {
    id: 'duration',
    disablePadding: false,
    label: 'Duration',
  },
  {
    id: 'assign',
    disablePadding: false,
    label: 'Assign',
  },
];
const tasks = [
  { id: 1, title: 'task01', duration: 60, assign: 'Alice' }, // min
  { id: 2, title: 'task02', duration: 120, assign: 'Bob' },
  { id: 3, title: 'task03', duration: 180, assign: 'John' },
  { id: 4, title: 'task04', duration: 360, assign: 'Alice' },
  { id: 5, title: 'task05', duration: 30, assign: 'Miles' },
  { id: 6, title: 'task06', duration: 220, assign: 'Bob' },
  { id: 7, title: 'task07', duration: 640, assign: 'John' },
  { id: 8, title: 'task08', duration: 250, assign: 'John' },
  { id: 9, title: 'task09', duration: 119, assign: 'Karen' },
  { id: 10, title: 'task10', duration: 560, assign: 'Henry' },
  { id: 11, title: 'task11', duration: 340, assign: 'Henry' },
  { id: 12, title: 'task12', duration: 45, assign: 'Bob' },
  { id: 13, title: 'task13', duration: 86, assign: 'Miles' },
  { id: 14, title: 'task14', duration: 480, assign: 'Henry' },
  { id: 15, title: 'task15', duration: 900, assign: 'John' },
]

function TasksTable({ selectData }) {
  const [order, setOrder] = React.useState('asc');
  const [orderBy, setOrderBy] = React.useState('Name');

  const handleRequestSort = (property) => {
    const isAsc = order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };
  return (
    <TableContainer component={Paper} className="rounded-md">
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <EnhanceTableHead
              orderBy={orderBy}
              order={order}
              handleRequestSort={handleRequestSort}
              headCells={headCells}
            />
          </TableRow>
        </TableHead>
        <TableBody >
          {
            stableSort(tasks, getComparator(order, orderBy))
              .map((row, index) => (
                <TableRow
                  key={row.name}
                  style={{ background: selectData && selectData['Name'] === row['assign'] ? '#EFF5FF' : '' }}
                  className={`${index % 2 === 0 ? 'bg-[#FAFAFA]' : ''} hover:bg-[#EEEEEE]`}
                  sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                >
                  <TableCell align="left">{row['title']}</TableCell>
                  <TableCell align="left">{row['duration']}</TableCell>
                  <TableCell align="left">{row['assign']}</TableCell>
                </TableRow>
              ))}
        </TableBody>
      </Table>
    </TableContainer>
  )
}

export default TasksTable
